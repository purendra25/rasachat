
## intent:affirm
- yes
- of course
- sure
- yeah
- ok
- cool
- go for it
- yep
- yep, will do thank you
- I'm sure I will!
- oh awesome!
- Yes
- accept
- I accept
- i accept
- ok i accept
- I changed my mind. I want to accept it
- ok cool
- alright
- i will!
- ok, I behave now
- yop
- oki doki
- yes please
- yes please!
- jo
- yep if i have to
- amayzing
- confirm
- nice
- coolio
- definitely yes without a doubt
- yas
- yup
- perfect
- sure thing
- absolutely
- Oh, ok
- Sure
- hm, i'd like that
- ja
- sure!
- yes i accept
- Sweet
- amazing!
- how nice!
- cool!
- yay
- yes accept please
- great
- oh cool
- yes
- fine
- i will take that
- that sounds just right

## intent:bye
- goodbye
- goodnight
- good bye
- good night
- see ya
- toodle-oo
- bye bye
- gotta go
- farewell
- catch you later
- bye for now
- bye
- bye was nice talking to you
- bye udo
- bye bye bot
- bye bot
- k byyye #slay
- tlak to you later
- ciao
- Bye bye
- then bye
- tschüssikowski
- bye!

## intent:deny
- no
- nope
- definitely not
- never
- absolutely not
- i don't think so
- i'm afraid not
- no sir
- no ma'am
- no way
- no sorry
- No, not really.
- nah not for me
- nah
- no and no again
- no go
- no thanks
- decline
- deny
- i decline
- never mind
- nevermind
- I'm not giving you my email address
- no I haven't decided yet if I want to sign up
- I don't want to give it to you
- I'm not going to give it to you
- no i don't accept
- no!!!!
- no you did it wrong
- no i can't
- i'm not sure
- NEIN
- nein
- not really
- i guess it means - no
- i don't want to
- i don't want either of those
- nah thanks
- neither of these
- i don't like that option
- neither will work
- suggest some other option
- is this the best you can do

## intent:greet
- Hi
- Hey
- Hi bot
- Hey bot
- Hello
- Good morning
- hi again
- hi folks
- hi Mister
- hi pal!
- hi there
- greetings
- hello everybody
- hello is anybody there
- hello robot
- hallo
- heeey
- hi hi
- hey
- hey hey
- hello there
- hi
- hello
- yo
- hola
- hi?
- hey bot!
- hello friend
- good morning
- hii
- hello sweet boy
- yoo
- hey there
- hiihihi
- hello sweatheart
- hellooo
- helloooo
- heyo
- ayyyy whaddup
- hello?
- Hallo
- heya
- hey bot
- howdy
- Hellllooooooo
- whats up
- Hei
- Well hello there ;)
- I said, helllllloooooO!!!!
- Heya
- Whats up my bot
- hiii
- heyho
- hey, let's talk
- hey let's talk
- jojojo
- hey dude
- hello it is me again
- what up
- hi there
- hi
- jop
- hi friend
- hi there it's me
- good evening
- good morning
- good afternoon

## intent:out_of_scope
- I want pizza
- please help with my ice cream it's dripping
- no wait go back i want a dripping ice cream but a cone that catches it so you can drink the ice cream later
- i want a non dripping ice cream
- hey little mama let em whisper in your ear
- someone call the police i think the bot died
- show me a picture of a chicken
- neither
- I want french cuisine
- i am hungry
- restaurants
- restaurant
- you're a loser lmao
- can i be shown a gluten free restaurant
- i don't care!!!!
- i do not care how are you
- again?
- oh wait i gave you my work email address can i change it?
- hang on let me find it
- stop it, i do not care!!!
- really? you're so touchy?
- how come?
- I changed my mind
- what?
- did i break you
- I don't wanna tell the name of my company
- that link doesn't work!
- you already have that
- this is a really frustrating experience
- no stop
- i want a french restaurant
- shit bot
- do you want to marry me?
- give me food
- i want food
- udo, I want to marry you
- i wanna party
- shitmuncher
- I like you
- i want pizza
- i want pizza!!
- silly bot
- i want to eat
- you are a stupid bot
- i hate you
- Can I ask you questions first?
- is it a wasteland full of broken robot parts?
- i can't deal with _your_ request
- are you vegan
- who will anser my email?
- do you sell vacuum robots?
- i want to buy a roomba for my grandson
- and make chicken noises into the phone
- is barbara still married to you
- what's your wife doing this weekend
- how are the kids
- you're rather dull
- personal or work?
- are you using Rasa Core and NLU ?
- tell me a joke
- what else?
- I already told you! I'm a shitmuncher
- I'm a shitmuncher
- who are the engineers at rasa?
- who are they?
- can we keep chatting?
- talk to me
- who is your favourite robot?
- a tamed mouse will arrive at your doorstep in the next couple of days
- you will know it from the single red rose it carries between its teeth
- i will tame a mouse for you
- isn't the newsletter just spam?
- go back
- can you help me with the docs?
- sorry, i cannot rephrase
- and your REST API doesn't work
- i told you already
- better than you
- oh my god, not again!
- you are a badass bot!
- lol
- why do you need that?
- is that any of your business
- can you help me with your docs?
- i immediately need help with implementing the coolest bot you can imagine
- can you help me with your docs
- can you tell me how to build a bot?
- can you learn from our conversation?
- common, just try
- hey, I contacted you a couple of days ago but didn't get any response, any news?
- please hurry, i have deadline in two weeks to deliver the bot it is for very big company
- you are annoying
- Do I have to accept?
- Is Rasa really smart?
- kannst du auch deutsch?
- are the newsletter worth the subscription?
- it's a pity
- i want more of you in my life!
- the one that is better than you
- you suck
- bots are bad
- i dont like bots
- do you have a phone number?
- where do you live?
- how are akela's cats doing?
- but I just told you that :(
- Why don’t you answer?
- But you're an english site :(
- can you help me to build a bot

## intent:thank
- Thanks
- Thank you
- Thank you so much
- Thanks bot
- Thanks for that
- cheers
- cheers bro
- ok thanks!
- perfect thank you
- thanks a bunch for everything
- thanks for the help
- thanks a lot
- amazing, thanks
- cool, thanks
- cool thank you
- thanks
- thanks!
- Cool. Thanks
- thanks
- thanks this is great news
- thank you
- great thanks
- Thanks!
- cool thanks
- thanks for forum link, I'll check it out
- thanks!

## intent:ask_budget
 - I want to eat at a place between 300 and 700
 - I am fine with an expensive place
 - I am looking for a dinner place at less than 300

## intent:ask_email
<!-- with 'email' entity -->
- can u mail me the information to [abc@abc.com](email)?
- can u mail to [test@tes.com](email)?
- can u mail me at [test-123.456@dom.123.co.in](email)?
- email address - [test.some@gmail.co.in](email). Mail this list.
- email me at [email-123@domina.com](email)
- mail me [emial@domain.io](email)
- my email address [email.123-abc@domain.123.com](email)
- please mail me the list to [123-email@domain.co.in](email)
- please send me the list to [123@domain.net](email)
- please send this to [email.123@123.456.com](email)
- send this to [abc-email@abc.com](email)
- send to [abc_123-email@abc123.com](email)
- this is my email address - [email-abc_123@abc.com.edu](email). send me an email.
- [email1_34-ret@host-name.123.com](email)
<!-- no entity -->
- can u share this information over email?
- can u send me an email?
- mail me the list
- email me a list of top 10 restaurants
- mail me the names of restaurants
- please send me an email
- please share this with me
- send me an email
- share some more restaurant names with me
- share this over mail
- share this information with me over email

## regex:email
- ([\w\.-]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)

## intent:ask_restaurant
<!-- only 'location' entity : 58 training samples-->
- Find me a place to eat in [Bangalore](location)
- I need a new restaurant in [Bengaluru](location)
- [Bhopal](location)
- help me find restaurant in [Bngalore](location)
- Could you find me a restaurant to eat at [bngalore](location)?
- [Bhubaneshwar](location)
- Can you find me a restaurant in [Bombay](location)?
- [Amritsar](location)
- [erode](location)
- [Jammu](location)
- [Kurnool](location)
- Hey, help me find a restaurant in [Mumbai](location)
- I need to find a restaurant in [Kolkata](location)
- [Pune](location)
- [Cyberabad](location)
- [calcuta](location)
- Find a restaurant for me in [Calcutta](location)
- Where should I eat in [Delhi](location)?
- [Delhi NCR](location)
- Suggest me a good restaurant around [New Delhi](location)
- [Bengaluru](location)
- [Amratsar](location)
- I need to find this restaurant in [Delhi](location)
- [Dilli](location)
- Show me the closest open restaurant in [Chennai](location)
- [Indore](location)
- [Jodhpur](location)
- Hey help me find a restaurant in [Madras](location)
- Help me find a restaurant in [Surat](location)
- Recommend me a restaurant around [Pune](location)
- [Goa](location)
- Could you find a restaurant for me in [Belgaum](location)? 
- [Chandigarh](location)
- [Rajahmundry](location)
- [Ujjain](location)
- Could you find a restaurant for me in [Bengaluru](location)? 
- Would you find me a restaurant in [Allahabad](location)??
- [vadodara](location)
- [Srinagar](location)
- Could you find me a restaurant in [Agra](location)? 
- Pick a restaurant for me, please in [Kochi](location)
- [Mysuru](location)
- How can you help me find a restaurant in [Jamshedpur](location)?
- [Thrissur](location)
- Can you find a restaurant for me in [Chandigarh](location)?
- [Lucknow](location)
- Would you find me a restaurant in [Visakhapatnam](location)??
- Could you find me a restaurant to eat at [Gurgaon](location)?
- [NewDelhi](location)
- [Surat](location)
- [Jamshedpur](location)
- Would you find me a restaurant in [calcutta](location)??
- Okay. Show me some in [bengaluru](location)
- Recommend me a restaurant around [Prayagraj](location)
- [Rourkela](location)
- [Vijayawada](location)
- [Ajmer](location)
- [Allahabad](location)
- [raurkela](location)
- Can you suggest some good restaurants in [bombay](location)
<!-- only 'cuisine' entity : 26 training samples -->
- I'm gonna need help finding a [indian](cuisine) restaurant
- [american](cuisine)
- i'm looking for a [Chinese](cuisine) restaurant
- Hey, can you help me with locating a [mexican](cuisine) restaurant
- i want a [french](cuisine) restaurant
- [chinese](cuisine)
- What's a good place to eat [mexican](cuisine) food
- Find a restaurant for me where I can eat [north indian](cuisine)
- Find a restaurant for me to eat [mexican](cuisine)
- [italian](cuisine)
- I am hungry, find me some place to go eat [italian](cuisine)
- Would you find a [south indian](cuisine) restaurant for me?
- Would you find a [american](cuisine) restaurant
- [north indian](cuisine)
- A place to eat [chinase](cuisine)
- I want to eat [italian](cuisine) food
- Please find me a [south-indian](cuisine) restaurant
- [south indian](cuisine)
- Quickly get me a [northindian](cuisine) place
- Where can i get [south-indina](cuisine) food?
- I need to find a restaurant [southindian](cuisine)
- [mexican](cuisine)
- A place to have [italian](cuisine) food
- Suggest me a good [mexican](cuisine) restaurant
- how can you help me find a [french](cuisine) restaurant?
- [italian](cuisine)
<!-- location + cuisine entities : 22 training samples -->
- I'm gonna need help finding a [indian](cuisine) restaurant in [Mysore](location)
- i'm looking for a [Chinese](cuisine) restaurant in [Lucknow](location)
- Hey, can you help me with locating a [mexican](cuisine) restaurant in [Lakhanpur](location)
- i want a [french](cuisine) restaurant in [Vizag](location)
- What's a good place to eat [mexican](cuisine) food in [Bangalore](location)
- Find a restaurant for me where I can eat [north indian](cuisine) in [Jaipur](location)
- Find a restaurant for me to eat [mexican](cuisine) at [Faridabad](location)
- I am hungry, find me some place to go eat [italian](cuisine) in [Goa](location)
- Would you find a [south indian](cuisine) restaurant for me in [Kozhikode](location)?
- Would you find a [american](cuisine) restaurant for me in [Trivandrum](location)?
- A place to eat [chinase](cuisine) in [Mysuru](location)
- Hey, can you help me with locating a [north indian](cuisine) restaurant in [calcuta](location)
- I want to eat [italian](cuisine) food in [cochin](location)
- Please find me a [south-indian](cuisine) restaurant in [madras](location)
- Quickly get me a [northindian](cuisine) place in [New Delhi](location)
- Where can i get [south-indina](cuisine) food in [Mangaluru](location)
- i'm looking for a [Chinese](cuisine) restaurant in [cyberabad](location)
- [chinese](cuisine) eating place in [mumbai](location)
- I want to eat [italian](cuisine) food in [Prayagraj](location)
- Okay. I want to eat [south indian](cuisine) in [allahabad](location)
- Okay. Show me some [north indian](cuisine) restaurants in [prayagraj](location)
- What's a good place to eat [mexican](cuisine) food in [chandighar](location)
<!-- no entity : 22 training samples -->
- I need to find a restaurant
- Can you find me a good restaurant?
- Would you be able to search a place to eat?
- A place to have food
- Feeling hungry, can you help
- I am hungry, find a restaurant
- Get me some food quickly
- Pick some place for me to eat quickly
- Where can i get some food to eat
- i'm looking for a restaurant
- how can you help me find a restaurant
- pick a restaurant for me
- please find a restaurant for me
- I'm hungry. Looking out for some good restaurants
- I want to eat
- I am feeling hungry
- I need a new restaurant
- Suggest me a good restaurant
- where should i eat?
- I'm gonna need help finding a restaurant
- Show me an open restaurant
- Find a restaurant for me to eat

## lookup:location
<!-- tier 1 cities -->
- Ahmedabad 
- Bangalore
- Chennai
- Delhi
- Hyderabad
- Kolkata
- Mumbai
- Pune
<!-- tier 2 cities -->
- Agra 
- Ajmer 
- Aligarh
- Allahabad
- Amravati 
- Amritsar 
- Asansol 
- Bareilly 
- Belgaum 
- Bhavnagar 
- Bhiwandi 
- Bhopal 
- Bhubaneswar 
- Bikaner 
- Chandigarh 
- Coimbatore 
- Nagpur 
- Cuttack 
- Dehradun 
- Dhanbad 
- Durgapur 
- Erode 
- Faridabad 
- Firozabad 
- Gulbarga 
- Guntur 
- Gwalior 
- Gurgaon 
- Guwahati 
- Indore 
- Jabalpur 
- Jaipur 
- Jalandhar 
- Jammu 
- Jamnagar 
- Jamshedpur 
- Jhansi 
- Jodhpur 
- Kakinada 
- Kannur 
- Kanpur 
- Kochi 
- Kottayam 
- Kolhapur 
- Kollam 
- Kozhikode 
- Kurnool 
- Lucknow
- Ludhiana 
- Madurai 
- Malappuram 
- Mathura 
- Goa 
- Mangalore 
- Meerut 
- Moradabad 
- Mysore 
- Nanded 
- Nashik 
- Nellore 
- Noida 
- Palakkad 
- Patna 
- Pondicherry  
- Raipur 
- Rajkot 
- Rajahmundry 
- Ranchi 
- Rourkela 
- Sangli 
- Siliguri 
- Solapur 
- Srinagar 
- Surat 
- Thiruvananthapuram 
- Thrissur 
- Tiruchirappalli 
- Tirunelveli 
- Tiruppur 
- Tiruvannamalai 
- Ujjain 
- Bijapur 
- Vadodara 
- Varanasi 
- Vijayawada 
- Visakhapatnam 
- Vellore 
- Warangal

## lookup:cuisine
- american
- chinese
- italian
- mexican
- north indian
- south indian

## synonym:chinese
- Chinese
- Chinase
- noodles

## synonym:south indian
- south-indian
- southindian
- south-indina
- South Indian
- idli dosa

## synonym:north indian
- north-indian
- northindian
- north-indina
- North Indian
- punjabi

## synonym:Bangalore
- Bengaluru
- bngalore
- bengalluru
- Bangalor
- bangalore
- bengaluru

## synonym:Delhi
- New Delhi
- Delhi NCR
- NewDelhi
- Dilli
- Dellhi
- newdelhi
- Newdelhi
- new delhi
- new Delhi

## synonym:Mumbai
- Bombay
- mumbai
- bombay

## synonym:Kolkata
- Calcutta
- kolkata
- kolkatta
- calcutta
- calcuta

## synonym:Chennai
- chennai
- madras
- Madras

## synonym:Hyderabad
- hyderabad
- Secunderabad
- secunderabad
- cyberabad
- Cyberabad

## synonym:Lucknow
- Lakhanpur

## synonym:Mysore
- mysore
- mysuru
- Mysuru

## synonym Kochi
- kochi
- cochin
- Cochin

## synonym:Mangalore
- mangalore
- mangaluru
- Mangaluru

## synonym:Visakhapatnam
- visakhapatnam
- Vizag
- vizag

## synonym:Thiruvananthapuram
- thiruvananthapuram
- trivandrum
- Trivandrum
- Travancore
- travancore

## synonym:Vadodara
- vadodara
- Vadodra
- vadodra
- Baroda
- baroda

## synonym:Jamshedpur
- jamshedpur
- Jamsedpur
- jamsedpur
- Tatanagar
- tatanagar

## synonym:Rajahmundry
- rajahmundry
- Rajahmundri
- rajahmundri
- Rajamundry
- rajamundry
- Rajamundri
- rajamundri

## synonym:Rourkela
- rourkela
- Raurkela
- raurkela

## synonym:Amritsar
- amritsar
- Amratsar
- amratsar

## synonym:Chandigarh
- chandigarh
- Chandighar
- chandighar

## synonym:Allahabad
- prayagraj
- Prayagraj
- Allahabad
- allahabad

## synonym:Nashik
- nashik
- Nasik
- nasik

## synonym:Pondicherry
- pondicherry
- puducherry
- Puducherry

## regex:greet
- hey[^\s]*

## regex:pincode
- [0-9]{6}

## regex:email
- ([\w\.-]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)
