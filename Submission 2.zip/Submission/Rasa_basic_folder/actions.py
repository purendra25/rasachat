from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals


from rasa_sdk import Action,Tracker
from rasa_sdk.events import SlotSet,AllSlotsReset,Restarted
import pandas as pd
import json
import smtplib
from email.message import EmailMessage
from rasa.shared.constants import (
    DEFAULT_DATA_PATH,
    DEFAULT_CONFIG_PATH,
    DOCS_URL_MIGRATION_GUIDE,
)

ZomatoData = pd.read_csv('zomato.csv',encoding="ISO-8859-1")

ZomatoData = ZomatoData.drop_duplicates().reset_index(drop=True)
WeOperate = ['Ahmedabad','Bengaluru', 'Chennai', 'Delhi', 'Hyderabad', 'Kolkata', 'Mumbai','Pune', 'Agra', 'Ajmer', 'Aligarh', 'Amravati', 'Amritsar', 'Asansol', 'Aurangabad', 'Bareilly', 'Belgaum', 'Bhavnagar', 'Bhiwandi', 'Bhopal', 'Bhubaneswar', 'Bikaner', 'Bilaspur','Bokaro Steel City', 'Chandigarh', 'Coimbatore',  'Cuttack', 'Dehradun', 'Dhanbad', 'Bhilai', 'Durgapur', 'Erode', 'Faridabad', 'Firozabad', 'Ghaziabad', 'Gorakhpur', 'Gulbarga', 'Guntur', 'Gwalior', 'Gurgaon', 'Guwahati','Hamirpur', 'Hubli-Dharwad', 'Indore', 'Jabalpur', 'Jaipur', 'Jalandhar','Jalgaon', 'Jammu', 'Jamnagar', 'Jamshedpur', 'Jhansi', 'Jodhpur', 'Kakinada', 'Kannur',' Kanpur','Karnal','Kochi','Kolhapur','Kollam','Kozhikode','Kurnool', 'Ludhiana','Lucknow','Madurai','Malappuram','Mathura','Mangalore','Meerut','Moradabad','Mysore', 'Nagpur','Nanded', 'Nashik','Nellore','Noida','Patna','Pondicherry','Purulia', 'Prayagraj','Raipur','Rajkot','Rajahmundry','Ranchi','Rourkela','Ratlam','Salem','Sangli','Shimla','Siliguri', 'Solapur','Srinagar','Sultanpur','Surat','Thanjavur','Thiruvananthapuram', 'Thrissur', 'Tiruchirappalli', 'Tirunelveli', 'Tiruvannamalai', 'Ujjain', 'Bijapur', 'Vadodara', 'Varanasi', 'Vasai-Virar City', 'Vijayawada', 'Visakhapatnam', 'Vellore', 'Warangal']

def RestaurantSearch(City,Cuisine,Budget):
    TEMP = ZomatoData[(ZomatoData['Cuisines'].apply(lambda x: Cuisine.lower() in x.lower())) & (ZomatoData['City'].apply(lambda x: City.lower() in x.lower()))]
    
    TEMP = filter_restaurant_by_budget(Budget,TEMP)
    return TEMP[['Restaurant Name','Address','Average Cost for two','Aggregate rating']]


class ActionSearchRestaurants(Action):
    def name(self):
     return 'action_search_restaurants'

    def run(self, dispatcher, tracker, domain):
        location = tracker.get_slot('location')
        cuisine = tracker.get_slot('cuisine')
        budget = tracker.get_slot("budget")
        search_validity = "valid"

        

        if not location:
            search_validity = "invalid"
        else:
            results = RestaurantSearch(City=location,Cuisine=cuisine, Budget = budget)
            
            response_message=""
            email_message = ""

            if results.shape[0] == 0:
                search_validity = "invalid"
                response_message= "no restaurants found"
            else:
                if len(results) > 0:
                    dispatcher.utter_message("Showing you top rated restaurants:")
                    number_of_records = 10
                    if len(results) < 10:
                        number_of_records = len(results)

                    index = 0 
                    for restaurant in results.iloc[:5].iterrows():
                        restaurant = restaurant[1]
                        if index < 5:
                            response_message=response_message + F"\n   {str(index + 1)} .  {restaurant['Restaurant Name']} in {restaurant['Address']} has been rated {restaurant['Aggregate rating']}\n"
                        index = index+1 
                         
                    indexemail = 0
                    for restaurant in results.iloc[:number_of_records].iterrows():
                        restaurantemail = restaurant[1]
                        if indexemail < 10:
                            email_message=email_message + F"\n   {str(indexemail + 1)} .  {restaurantemail['Restaurant Name']} in {restaurantemail['Address']} Average cost for 2 : {restaurantemail['Average Cost for two']} has been rated {restaurantemail['Aggregate rating']}\n"
                        indexemail = indexemail+1

                    
                else:
                    search_validity = "invalid"

        if search_validity == "valid":
             dispatcher.utter_message(response_message)

        return [SlotSet("search_validity", search_validity), SlotSet("email_message", email_message)]

class ActionSendEmail(Action):
    def name(self):
     return 'action_send_email'

    def run(self, dispatcher, tracker, domain):


        location = tracker.get_slot('location')
        cuisine = tracker.get_slot('cuisine')
        email_id = tracker.get_slot('email')
        email_message = tracker.get_slot("email_message")

        """
        Parse email id  sent from SLACK connector
        """

        str_email_id = str(email_id)
        if str_email_id.startswith("mailto"):
           separator_index = str_email_id.index("|")
           if separator_index > -1:
               emails = str_email_id.split("|")
               email_id = emails[1]

        """
        Read SMTP configuration from smtp text file
        """
        smtp_config = {}
        filepath = DEFAULT_DATA_PATH + "/smtpconfig.txt"

        with open(filepath) as mail_file:
             for line in mail_file:
                 name, var = line.partition("=")[::2]
                 smtp_config[name.strip()] = var.strip()

        """
        Create an email message
        """
        message = EmailMessage()

        email_message = "Hello,\n"+"  "+ email_message+"\n\nThank You"
              

        message.set_content(email_message)
        message['Subject'] = "List of {0} Restaurants in {1}".format(cuisine, location)
        try:
          s = smtplib.SMTP_SSL(host=smtp_config["smtpserver_host"], port=smtp_config["smtpserver_port"])
          s.login(smtp_config["username"], smtp_config["password"])

          message['From'] = smtp_config["from_email"]
          message['To'] = email_id
          s.send_message(message)
          s.quit()
        except Exception as e:
          print("failed to send an email !!!!")
          print(e)

        return [AllSlotsReset()]




class ActionRestarted(Action):
    def name(self):
      return 'action_restart'

    def run(self, dispatcher, tracker, domain):
      return[Restarted()]


class ActionSlotReset(Action):
    def name(self):
      return 'action_slot_reset'

    def run(self, dispatcher, tracker, domain):
      return[AllSlotsReset()]


"""
   Action to validate user location
"""

class ActionValidateLocation(Action):
    def name(self):
        return "action_location_valid"

    def run(self, dispatcher, tracker, domain):

        location = tracker.get_slot("location")
        loc_validity = "valid"

        if not location:
            loc_validity = "invalid"
            
        else:
            cities_lower = [city.lower() for city in WeOperate]

            loc_validity = (
               "invalid"
               if location.lower() not in cities_lower
                else "valid"
              )

        return [SlotSet("location_validity", loc_validity)]


"""
   Set the budget range based on input
"""

def filter_restaurant_by_budget(budget, restaurant_df):

        rangeMin = 0
        rangeMax = 999999

        if budget == "299":
            rangeMax = 299
        elif budget == "700":
            rangeMin = 300
            rangeMax = 700
        elif budget == "701":
            rangeMin = 701
        else:
            # Default budget
            rangeMin = 0
            rangeMax = 9999

        df_restaurant = restaurant_df[(restaurant_df['Average Cost for two'].apply(lambda x: ( int(x) >= rangeMin and int(x) <= rangeMax)))]
        
        final_df = df_restaurant.sort_values(by=['Aggregate rating'], ascending=False)
      
        return final_df


""" Action to validate input cuisine
"""
class ActionValidateCuisine(Action):
    def name(self):
        return "action_cuisine_valid"

    def run(self, dispatcher, tracker, domain):

        cuisine = tracker.get_slot("cuisine")
        cuisine_validity = "valid"

        if not cuisine:
            cuisine_validity = "invalid"
        else:
            supported_cuisines = [
                "american",
                "chinese",
                "italian",
                "mexican",
                "north indian",
                "south indian",
            ]

            cuisine_validity = (
                "invalid" if cuisine.lower() not in supported_cuisines else "valid"
            )

        return [SlotSet("cuisine_validity", cuisine_validity)]
